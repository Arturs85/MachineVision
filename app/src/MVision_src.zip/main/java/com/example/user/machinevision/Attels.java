package com.example.user.machinevision;

import java.util.ArrayList;

/**
 * Created by user on 2016.09.18..
 */
public  class Attels {
    boolean[] ekstremi= new boolean[307200];
    boolean[] ekstremiVertikali;
    static HorizontalaLinija linijaH;
byte[] datuMasivs;
    int summa1=0;
    int summa2 = 0;
    int summaY = 0;
    int skaits = 0;
    ArrayList<HorizontalaLinija> linijas;
    int spilgtumsDelta = 20;
    //KrasainaBilde krasainaBilde;
   // EkstremuBilde ekstremuBilde;
   // EkstremuBilde vertikaluEkstremuBilde;
   // LinijuBilde linijuBilde;
   // TirasLinijas tiraBilde;
    ArrayList<HorizontalaLinija> mekletHorLinijas(byte[] datuMasivs){
        int kolonna = 0;
        int rinda = 0;
       int sakumaKoordinateX=0;
        int sakumaKoordinateY = 0;
        int linijasGarums=0;
       linijas = new ArrayList<HorizontalaLinija>();
       // if (ekstremi==null){
         ekstremi = atrastEkstremus(datuMasivs,ekstremi);
     //   }
        boolean velkLiniju = false;
        for(int a =0;a<=ekstremi.length-2;a++ ){

            if (ekstremi[a]==false&&ekstremi[a+1]==true){
                velkLiniju = true;
                sakumaKoordinateX = kolonna;
                sakumaKoordinateY = rinda;

            }
            if (ekstremi[a]==true&&ekstremi[a+1]==true){
                velkLiniju = true;
                linijasGarums++;

            }
            if (ekstremi[a]==true&&ekstremi[a+1]==false){
                velkLiniju = false;
                if (linijasGarums>100){
//linijaH = new HorizontalaLinija(sakumaKoordinateX,sakumaKoordinateY,kolonna);
                    linijas.add(new HorizontalaLinija(sakumaKoordinateX,sakumaKoordinateY,kolonna));



                }
                linijasGarums = 0;
            }

            kolonna++;
            if(kolonna>=640){
                rinda++;
                linijasGarums = 0;
                kolonna = 0;
            }
        }

        return linijas;

    }
    //*
    ArrayList<HorizontalaLinija> atlasitLinijas (ArrayList<HorizontalaLinija> visasLinijas)
    {
       for (int a = 0; a<=visasLinijas.size()-2 ;a++) {

           pieskaititBlakusliniju(a,visasLinijas);
           visasLinijas.get(a).sakumaX=summa1/skaits;
           visasLinijas.get(a).beiguX=summa2/skaits;
visasLinijas.get(a).y = summaY/skaits;

          /// / int pieskaitamais = 1;

       }
        return visasLinijas;

    }
        void pieskaititBlakusliniju(int indeks,ArrayList<HorizontalaLinija> visasLinijas){
        int pieskaitamais = 0;
            skaits=1;
            summa1=visasLinijas.get(indeks).sakumaX;
            summa2 = visasLinijas.get(indeks).beiguX;
            summaY = visasLinijas.get(indeks).y;
           //ignoreet tajaa pat rindaa esossaas liinijas
            do{
                pieskaitamais++;


        }while (visasLinijas.get(indeks).y==visasLinijas.get(indeks+pieskaitamais).y&& indeks+pieskaitamais<visasLinijas.size()-2);


        // ja ir blakusliinija
       // ArrayList<HorizontalaLinija> visasLinijas ;

        if(visasLinijas.get(indeks+pieskaitamais).y <= visasLinijas.get(indeks).y+2
                &&visasLinijas.get(indeks+pieskaitamais).sakumaX<visasLinijas.get(indeks).beiguX
            &&visasLinijas.get(indeks+pieskaitamais).beiguX>visasLinijas.get(indeks).sakumaX
        && indeks+pieskaitamais<visasLinijas.size()-2  )
        {
            // indeks++;
                summa1 =summa1 +visasLinijas.get(indeks+pieskaitamais).sakumaX;
                summa2 = summa2 + visasLinijas.get(indeks+pieskaitamais).beiguX;
                summaY = summaY + visasLinijas.get(indeks+pieskaitamais).y;
                skaits++;


                pieskaititBlakusliniju(indeks + pieskaitamais + 1, visasLinijas);
                visasLinijas.remove(indeks+pieskaitamais);

            return;
        }
        else

            return;

    }
   //*/
    boolean[] atrastVisusEkstremus(byte[] datuMasivs){
        ekstremi  = new boolean[307200];
        ekstremi =    atrastEkstremus(datuMasivs,ekstremi);
        ekstremi = atrastVertEkstremus(datuMasivs,ekstremi);
        return ekstremi;
    }
    boolean[] atrastEkstremus(byte[] dati,boolean[] ekstremi){
       // boolean[] ekstremi =   new boolean[245760];
        for (int a = 0; a < 307200-2561;  a = a + 1) {
            if(noteiktMalu(dati[a],dati[a+640],dati[a+640*2],dati[a+640*3]))
            {
                ekstremi[a]= true;
            }
            else{
            if(noteiktMalu(dati[a],dati[a+1],dati[a+2],dati[a+3]))
            {
                ekstremi[a]= true;
            }
            else
                ekstremi[a]=false;
            }

        }
        return ekstremi;
    }
    boolean[] atrastVertEkstremus(byte[] dati,boolean[] ekstremi){
       // boolean[] ekstremiVertikali =   new boolean[245760];
        for (int a = 0; a < 307200-4;  a = a + 1) {
            if(noteiktMalu(dati[a],dati[a+1],dati[a+2],dati[a+3]))
            {
                ekstremi[a]= true;
            }
            //else
              //  ekstremiVertikali[a]=false;

        }
        return ekstremi;
    }
    boolean noteiktMalu(int a,int a1,int a2,int a3){
        boolean irMala = false;
        if(a+a1<a2+a3-spilgtumsDelta||a+a1>a2+a3+spilgtumsDelta)
            irMala = true;


        return irMala;
    }

//Attels apakssklase
 class HorizontalaLinija {
    int sakumaX;
    int y;
    int beiguX;

    HorizontalaLinija(int sakumaX,int y,int beiguX){
        this.sakumaX = sakumaX;
        this.y = y;
        this.beiguX = beiguX;

    }
    int getGarums(){
        int garums=0;
        garums = beiguX-sakumaX;
        return garums;
    }
}


}
